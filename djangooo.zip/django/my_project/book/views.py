from django.shortcuts import render


# Create your views here.
def index2(request):
    return render(request, "index2.html", {"book":"cs"})


# Create your views here.
