from django.urls import path, include

from . views import index2

urlpatterns = [
    path('book/', index2, name="index2"),
    
]